var searchData=
[
  ['gamma_20ramp_20support',['Gamma ramp support',['../group__gamma.html',1,'']]]
];
